var searchData=
[
  ['derivatives_2ecpp',['derivatives.cpp',['../derivatives_8cpp.html',1,'']]],
  ['derivatives_2eh',['derivatives.h',['../derivatives_8h.html',1,'']]]
];
