var searchData=
[
  ['uniforms',['uniforms',['../classder_1_1_random_base.html#addeea6d693d9fd7a2774610bfbafdc6a',1,'der::RandomBase::uniforms()'],['../classder_1_1_anti_thetic.html#a5cc63ec3417c73284bebd4cb1bb518b6',1,'der::AntiThetic::uniforms()'],['../classder_1_1_random_park_miller.html#abd3a4c8da97ec97ce20eaff378b775d4',1,'der::RandomParkMiller::uniforms()']]]
];
