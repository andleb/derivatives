var searchData=
[
  ['b',['b',['../namespacerandom.html#a2303d402cdd21a19d98aa84fe55f7043',1,'random']]],
  ['bins',['bins',['../namespacerandom.html#ac9d63567eec4aa4c7e61bdc23905b06c',1,'random']]]
];
