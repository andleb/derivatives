var searchData=
[
  ['optionstype',['OptionsType',['../namespaceder.html#a6a65a5e435a1253ac42e150ca064e8f3',1,'der']]]
];
