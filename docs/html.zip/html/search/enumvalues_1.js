var searchData=
[
  ['digital',['digital',['../namespaceder.html#a6a65a5e435a1253ac42e150ca064e8f3ae0e1d64fdac4188f087c4d44060de65e',1,'der']]]
];
