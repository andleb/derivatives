var searchData=
[
  ['gaussians',['gaussians',['../classder_1_1_random_base.html#a8d2229faba1057d23d77341e650afe2f',1,'der::RandomBase']]]
];
