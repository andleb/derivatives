var searchData=
[
  ['normaldist',['normalDist',['../namespaceder.html#a3db166789be44c7c6984a53d8e78114d',1,'der']]]
];
