var searchData=
[
  ['der',['der',['../namespaceder.html',1,'']]]
];
